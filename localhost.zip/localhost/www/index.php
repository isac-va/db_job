<?require_once("$_SERVER[DOCUMENT_ROOT]/../db/dal.inc.php");?>
<?php 
	
	//Обработчик нажатия на кнопку "Сохранить" в модальном окне #action
	if(isset($_POST["add"])) {
		// Получение значений из элементов управления
		$f_title=mysqli_real_escape_string($cms_db_link,$_POST["f_title"]);
		$f_content=mysqli_real_escape_string($cms_db_link,$_POST["f_content"]);
		$f_sectionID=(int)$_POST["f_sectionID"];
		$f_salary=(int)$_POST["f_salary"];
		$f_experience=(int)$_POST["f_experience"];
		$f_isMain=(int)$_POST["f_isMain"];
		$f_isPartnership=(int)$_POST["f_isPartnership"];
		$f_isRemote=(int)$_POST["f_isRemote"];
		if(isset($_POST["f_ID"]))
			$f_ID=(int)$_POST["f_ID"];

		
			$errmsg="";
			try {
				if($f_ID == "")
					//,$f_isMain,$f_isPartnership,$f_isRemote
					DBCreateVacancy($f_title,$f_sectionID,$f_title,$f_content,$f_salary,$f_experience,$f_isMain,$f_isPartnership,$f_isRemote);
				else
					DBUpdateVacancy($f_ID,$f_sectionID,$f_title,$f_content,$f_salary,$f_experience,$f_isMain,$f_isPartnership,$f_isRemote);
			header("Location:$_SERVER[PHP_SELF]");
			}catch(Exception $ex){
				$errmsg=$ex->getMessage();
			}
		
	}//add
?>
<!DOCTYPE html>
<html>
	<head>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" />
		<!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" /> -->
		<script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
		<!-- <script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>		 -->
		<link rel="stylesheet" href="https://cdn.datatables.net/1.10.24/css/dataTables.bootstrap4.min.css" />
		<link rel="stylesheet" href="https://cdn.datatables.net/1.10.24/js/dataTables.bootstrap4.min.css" />
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
		<!-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script> -->

		<!-- Наша собственная библиотека my_input_validator-->
		<script src="my_input_validator.js"></script>
	  
		<script type="text/javascript">
			//Объектный подход	
			$(function() {
			  
			  
			  // Регулярные выражения для проверки введённых значений
			  
			  var reg_salary = /^[0-9]+$/;
			  var reg_experience = /^[0-9]+$/;
			  $("input").css("border-color", "default");
			  //Создание экземпляра объекта формы
			  var my_form = new InputForm("#user_form");
			  
			  //Создание экземпляров объекта полей ввода
			  var f_title_form = new InputField("#f_title_form",my_form);
			  var f_content_form = new InputField("#f_content_form",my_form);
			  var f_salary_form = new InputField("#f_salary_form",my_form);
			  var f_experience_form = new InputField("#f_experience_form",my_form);
			  //Подписка на callback-функцию beforesubmit, объявленную в 
			  //классе InputForm, и вызываемую при попытке отправки формы
			  my_form.beforesubmit = function() {
				  //Собственно процесс валидации
				  f_title_form.validate(f_title_form.v()=="");				
				  f_content_form.validate(f_content_form.v()=="");
				  f_salary_form.validate(!reg_salary.test(f_salary_form.v()));
				  f_experience_form.validate(!reg_experience.test(f_experience_form.v()));

			  }	
		  });
		  $(function() {
				var dataTable = $('#vacancy_data').DataTable({
						"language": {"url":"http://cdn.datatables.net/plug-ins/1.10.20/i18n/Russian.json"},
						"processing":true,
						"serverSide":true,
						"order":[],
						"ajax":{
							url:"/rest/vacancy",
							type:"POST"
						},
						"columnDefs":[
							{
								"targets":[3, 4], // Столбцы, по которым не нужна сортировка
								"orderable":false,
							},
						],
				});	

				dataTable.ajax.reload();
				
				$(document).on('submit', '#user_form', function(event){
					event.preventDefault();					
					
					//data.Nazvanie (получить значение селектора)
					  var vacancy_info = {
						"ID_user":$("#f_ID").val(),
						"SectionID":$("#f_sectionID").val(),
					  	"Title":$("#f_title_form").val(),
					  	"Content":$("#f_content_form").val(),
						"Salary":$("#f_salary_form").val(),
					  	"Experience":$("#f_experience_form").val(),
					  	"IsMain":$("#f_isMain").val(),
					  	"IsPartnership":$("#f_isPartnership").val(),
					  	"IsRemote":$("#f_isRemote").val()
					  	
					  };
					
				
					send_form_data();	
					

					//Функция отправки данных
					function send_form_data(){
						var method="PUT";
						if($("#userModal #operation").val()==1) {
							method="PATCH";
							vacancy_info.ID = $("#vacancy_id").val();						
						}		
							
					
						$.ajax({
								url:"/rest/vacancy",
								method: method,
								data: JSON.stringify(vacancy_info),
								headers: {
									"Content-type":"application/json"
								},
								success:function(data)
								{									
									$('#user_form')[0].reset();
									$('#userModal').modal('hide');
									dataTable.ajax.reload();
								}
						});
					}
				});
				
				$(document).on('click', '.update', function(event){
					//Режим редактирования (кнопка Редактировать)
					var id = $(this).attr("id");// ID строки					
					
					
					$.ajax({
								url:"/rest/vacancy?id="+id,
								method:'GET',
								dataType: "json",								
								success:function(data)
								{
									dataTable.ajax.reload();
																		
									//Заголовок окна
									$('.modal-title').text("Редактировать запись");
									
									//Вывод принятых с сервера данных в поля формы
									 $("#userModal #f_title_form").val(data.Title);
									 $('#userModal #f_sectionID').val(data.SectionID);
									 $("#userModal #f_content_form").val(data.Content);	
									 $("#userModal #f_salary_form").val(data.Salary);
									 $("#userModal #f_experience_form").val(data.Experience);
									 $('#userModal #vacancy_id').val(id);
									 $('#userModal #f_isMain').val(data.IsMain);
									 $('#userModal #f_isPartnership').val(data.IsPartnership);
									 $('#userModal #f_isRemote').val(data.IsRemote);
									
									// //Флаг операции (1 - редактирование)
									 $("#userModal #operation").val("1");
									
									// //Текст на кнопке
									 $("#userModal #action").val("Сохранить изменения");
									
									// //Отобразить форму
									 $('#userModal').modal('show');									
								}
							});
					
					event.preventDefault();
				});
				
				// Кнопка "Добавить" на странице
				$("#add2").click(function() {
					//Режим добавления (кнопка Добавить)
					
					//Заголовок окна
					$('.modal-title').text("Добавить вакансию");
					//Текст на кнопке (в модальном окне)
					$("#userModal #action").val("Добавить");
					//Флаг операции (0- добавление)
					$("#userModal #operation").val("0");
				});
				
				$(document).on("click",".delete",function() {
					//Режим удаления (кнопка Удалить)
					var vacancy_id = $(this).attr("id");// ID строки				
					
					if(confirm("Действительно удалить?"))
					{
						$.ajax({
							url:"/rest/vacancy?id="+vacancy_id,
							method:"DELETE",							
							success:function(data)
							{								
								dataTable.ajax.reload();
							}
						});
					}
					else
					{
						return false;	
					}
				});				
			});
	  	</script>
		
		
		</head>
	<body>
	
	

	
		<div class="container box">
			<div class="table-responsive">
				<br />
				<div align="right">
					<button type="button" id="add_button" data-toggle="modal" data-target="#userModal" class="btn btn-info btn-lg">Добавить</button>
				</div>
				<br /><br />
				<table id="vacancy_data" class="table table-bordered table-striped">
					<thead>
						<tr>
							<th width="10%">Дата публикации</th>
							<th width="10%">Должность</th>
							<th width="10%">Зарплата</th>
							<th width="10%"></th>
							<th width="10%"></th>
						</tr>
					</thead>
				</table>			
			</div>
		</div>
		
		<div id="userModal" class="modal fade">
			<div class="modal-dialog">
				<form method="post" id="user_form" enctype="multipart/form-data">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal">&times;</button>
							<h4 class="modal-title">Добавить вакансию</h4>
						</div>
						<div class="modal-body">
							
							<label for="f_title_form">Должность</label>
							<input type="text" name="f_title_form" id="f_title_form" class="form-control" />
							
							<fieldset class="form-group">
								<label for="f_sectionID">Секция</label>
								<select class="custom-select" id="f_sectionID" name="f_sectionID">
								<option value="0">--Выберите секцию--</option> 
								<option value="1">Ремонт электроники</option>
								<option value="2">Программирование</option>
								<option value="3">Финансовый анализ</option>
								<option value="4">Бухучет</option>
								</select><br/>
							</fieldset>

						<label for="f_content_form">Описание</label>
						<textarea id="f_content_form" name="f_content_form"  class="form-control form-control-lg ">  </textarea><br/>
						
						<div class="form-row">
							<div class="form-group col-md-6">
								<label for="f_experience_form">Требуемый стаж работы</label>
								<input id="f_experience_form" name="f_experience_form"  class="form-control"  /> 
							</div>
							
							<div class="form-group col-md-6">
								<label for="f_salary_form">Зарплата</label>
								<input id="f_salary_form" name="f_salary_form" type="int" class="form-control"  />
							</div>
						</div>
						
							
						<label>Возможные режимы работы:</label>
					 
						<div class="custom-control custom-checkbox">
							<input type="checkbox" id="f_isMain" name="f_isMain" class="custom-control-input" >
							<label class="custom-control-label" for="f_isMain">Основная</label>
						</div>
						
						<div class="custom-control custom-checkbox">
							<input type="checkbox" id="f_isPartnership" name="f_isPartnership" class="custom-control-input" >
							<label class="custom-control-label" for="f_isPartnership">Совмещенная</label>
						</div>
					
						<div class="custom-control custom-checkbox">
							<input type="checkbox" id="f_isRemote" name="f_isRemote" class="custom-control-input" />
							<label class="custom-control-label" for="f_isRemote">Удаленная</label>
						</div>	
							
							
						</div>
							<div class="modal-footer"><!-- Подвал модальной формы -->
							<input type="hidden" name="vacancy_id" id="vacancy_id" />
							<input type="hidden" name="operation" id="operation" />
							<input type="submit" name="action" id="action" class="btn btn-success" value="Добавить" />
							<button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>
						</div>
					</div>
				</form>
			</div>
		</div>
	</body>
</html>
			