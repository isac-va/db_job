<? 
 require_once("$_SERVER[DOCUMENT_ROOT]/../includes/flight/Flight.php");
 require_once("$_SERVER[DOCUMENT_ROOT]/../db/dal.inc.php");
  
 function CreateUser() {
		DBCreateVacancy (
		Flight::request()->data["ID_user"],
		Flight::request()->data["SectionID"],
		Flight::request()->data["Title"],
		Flight::request()->data["Content"],
		Flight::request()->data["Salary"],
		Flight::request()->data["Experience"],
		Flight::request()->data["IsMain"],
		Flight::request()->data["IsPartnership"],
		Flight::request()->data["IsRemote"]
		);
	//Получаем его id
	$vacancy_id=_DBInsertID();
	
 }
 Flight::route('PUT /rest/vacancy',"CreateUser");
 
 function ReadUser($id) {
	Flight::json(DBGetVacancy($id));
 }
 Flight::route('GET /rest/vacancy\?id=@id',"ReadUser");
 
 function ReadUsers() {
	$data=Array();

	while($row=DBFetchVacancy(
		$_POST["search"]["value"],
		$_POST['order']['0']['column'],
		$_POST['order']['0']['dir'],
		$_POST['start'],$_POST["length"])) 
	{
		$data[]=Array($row["DateTime"], $row["Title"], $row["Salary"],
		'<button type="button" name="update" id="'.$row["ID"].'" class="btn btn-warning btn-xs update">Редактировать</button>',
		'<button type="button" name="delete" id="'.$row["ID"].'" class="btn btn-danger btn-xs delete">Удалить</button>');
	}


	//Отправка данных клиенту в формате JSON (JavaScript Object Notation)
	Flight::json(Array(
			"draw"				=>	intval($_POST["draw"]),
			"recordsTotal"		=> 	count($data),
			"recordsFiltered"	=>	DBCountAllVacancy(),
			"data"				=>	$data
	));
	
 }
 Flight::route('POST /rest/vacancy',"ReadUsers");
 
 function UpdateUser() {
	 DBUpdateVacancy(
		Flight::request()->data["ID"],
		Flight::request()->data["SectionID"],
		Flight::request()->data["Title"],
		Flight::request()->data["Content"],
		Flight::request()->data["Salary"],
		Flight::request()->data["Experience"],
		Flight::request()->data["IsMain"],
		Flight::request()->data["IsPartnership"],
		Flight::request()->data["IsRemote"]

	);
 }
 Flight::route('PATCH /rest/vacancy',"UpdateUser");
 
 function DeleteUser($id) {
	 DBDeleteVacancy($id);
 }
 Flight::route('DELETE /rest/vacancy\?id=@id',"DeleteUser"); 

 Flight::start();
