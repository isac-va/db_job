<?php
$cms_connect_host = "localhost";
$cms_connect_login = "root";
$cms_connect_password = "";
$cms_db_name = "db_job";